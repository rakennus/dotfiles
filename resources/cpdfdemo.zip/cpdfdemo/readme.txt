INSTALLING COMMAND LINE TOOLS

The executable 'cpdf' should be copied to a location somewhere on your path. It
can then be used from the command prompt.  (You can see your path by typing echo
%PATH% at the command prompt). One such place is C:\Windows\

If you wish to linearize PDF files, you must also install the executable and
DLLs in the linearize folder. Cpdf knows how to find this executable when it
needs it. See Section 1.11 of the manual for further details. Again, a suitable
place might be C:\Windows\
