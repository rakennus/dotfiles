Original source: https://sourceforge.net/projects/qpdf/
